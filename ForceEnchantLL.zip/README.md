# ForceEnchantLL v1.6.0

Exact native port for:

- Minecraft Bedrock Android **1.26.44.3** (`arm64-v8a`)
- Levi Launchroid **1.5.15**
- Preloader package type: `preload-native`

This source is tied to the exact supplied `libminecraftpe.so` and `libpreloader.so` builds. The runtime scanner verifies unique instruction signatures before writing any patch.

## Features

- `/enchant` accepts levels through **32767**.
- Real non-vanilla enchantment storage on arbitrary items.
- Requested enchantment levels are passed to Bedrock unchanged; ForceEnchantLL does not apply a per-enchantment level-10 clamp.
- Stored-enchantment glint compatibility by redirecting both verified `Item::isGlint(ItemStackBase const&)` render call sites from the strict typed `ench` check to Minecraft's adjacent raw `ench`-existence check.
- Mod Menu integration for Levi Launchroid 1.5.15:
  - **Roman Numerals** — default OFF.
  - **Double Item Stats** — default ON.
- Roman formatting:
  - OFF: `32767`
  - ON: `XXXMMDCCLXVII`
- Optional ×2 item-stat layer:
  - durable-item maximum durability ×2;
  - armor points ×2;
  - armor toughness ×2.

## Exact binary fingerprints

### Minecraft 1.26.44.3

- SHA-256: `4492ce15ceda3bb4865788a50e8d35b1bbafd45b62ce441440240a693a97d749`
- GNU Build ID: `b480c79a54f33d6e4f0d63a131673e3daf749911`

### Levi Launchroid 1.5.15 preloader

- SHA-256: `e337b78a844677c676712e22ac46d68165b31ca592567903f9a9a092b78c9b3c`
- GNU Build ID: `ab3bb7e43445416d5c58ebf4d7b05da70ab1b42f`

## Important scope

ForceEnchantLL preserves high stored enchantment levels and passes them to the original Bedrock logic. A particular enchantment can still contain its own saturation, probability, or arithmetic limit inside Minecraft. Those independent effect formulas are not globally replaced by the storage patch.

The ×2 stat hooks operate on item definitions, not individual `ItemStack` instances. While enabled, they affect compatible armor and durable item families globally.

## Build

```sh
MCBE_BINARY=/path/to/libminecraftpe.so \
PRELOADER_BINARY=/path/to/libpreloader.so \
./scripts/build.sh
```

Output:

```text
build/libForceEnchantLL_V1.6.0_MCBE-1.26.44.3_Levi-1.5.15.levipack
```

The build script runs `scripts/verify_build.py` and refuses a binary whose SHA-256 or required signatures do not match the supplied target builds.

## v1.6.0 — 1.26.44.3 port

Relocated and byte-verified against the supplied 1.26.44.3 engine:

- command range RVA `0x08FA237C`;
- any-item validation patch RVA `0x08FA25C0`;
- real-storage patch RVAs `0x08FA26C0` and `0x08FA27A4`;
- typed/raw `ench` checks `0x0F6401CC` / `0x0F6401EC`;
- `Item::isGlint` call sites `0x0F510D08` and `0x0F667E48`;
- Roman formatter selector/numeric block `0x0F310E60` / `0x0F310FB8`;
- durability getters `0x0F46D044` and `0x0F667A5C`;
- armor/toughness getters `0x0F660BB0` / `0x0F660BB8`.

The supplied Levi 1.5.15 `libpreloader.so` has the same SHA-256 and Build ID as the previously supplied preloader, so the verified Mod Menu ABI remains unchanged.

## v1.6.0 toggle crash fix

The live JNI setter patch from v1.5.0 was removed. Levi 1.5.15 now delivers
`roman_numerals` and `double_item_stats` changes through a native
`onConfigChanged` callback whose inline object, clone, invoke, destroy, and
RTTI slots match the supplied preloader's Android libc++ ABI-v1 layout.

## v1.6.0 execute-only signature recovery

On the reported device, the command/storage signatures were readable but the
late glint, NBT lookup, Roman formatter, and item-stat getter pages were mapped
execute-only. The readable-region scan therefore returned zero for those
optional paths even though the supplied 1.26.44.3 binary contains them.

v1.6.0 now:

- treats only `range`, `anyItem`, and both storage sites as mandatory;
- recovers late optional sites from exact verified RVAs relative to the unique
  command signature;
- changes only the individual target pages to read+execute before verifying
  their original instructions;
- continues the enchantment core with warning-only fallbacks if a visual or
  stat path cannot be verified.
