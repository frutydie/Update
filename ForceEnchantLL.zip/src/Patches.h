#pragma once

#include "MemoryMap.h"

namespace force_enchant {

enum class ApplyResult : int {
    Waiting = 0,
    Active = 1,
    PermanentFailure = 2,
};

FE_HIDDEN ApplyResult locateAndApplyPatches();
FE_HIDDEN bool requiredPatchesActive();
FE_HIDDEN void revertAllPatches();

} // namespace force_enchant
