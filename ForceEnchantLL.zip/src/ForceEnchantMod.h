#pragma once

#include "Types.h"

namespace force_enchant {
FE_HIDDEN bool load();
FE_HIDDEN bool enable();
FE_HIDDEN bool disable();
FE_HIDDEN bool unload();
}
