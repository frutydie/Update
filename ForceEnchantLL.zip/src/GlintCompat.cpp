#include "GlintCompat.h"
#include "MemoryMap.h"
#include "Platform.h"

namespace force_enchant {
namespace {
inline constexpr size_t ExpectedSites = 2u;
inline constexpr uint32_t ItemGlintTail[3] = {
    0x79422668u, // LDRH W8,[X19,#0x112] (static item glint flags)
    0x2A080008u, // ORR W8,W0,W8
    0x12000100u, // AND W0,W8,#1
};

struct CallPatch {
    uintptr_t address{};
    uint32_t original{};
    uint32_t replacement{};
    volatile int state{}; // 0 inactive, 1 ours, 2 already redirected.
};

CallPatch Patches[ExpectedSites]{};
volatile unsigned InstalledCount = 0u;

FE_HIDDEN uintptr_t decodeBranch(uintptr_t instructionAddress,
                                 uint32_t instruction) {
    if ((instruction & 0x7C000000u) != 0x14000000u) return 0;
    long long immediate = static_cast<long long>(instruction & 0x03FFFFFFu);
    if (immediate & 0x02000000ll) immediate |= ~0x03FFFFFFll;
    return static_cast<uintptr_t>(
        static_cast<long long>(instructionAddress) + (immediate << 2));
}

FE_HIDDEN uint32_t encodeBl(uintptr_t instructionAddress, uintptr_t target) {
    const long long delta = static_cast<long long>(target) -
                            static_cast<long long>(instructionAddress);
    if ((delta & 3ll) != 0 || delta < -(1ll << 27) || delta >= (1ll << 27))
        return 0;
    return 0x94000000u |
           (static_cast<uint32_t>(delta >> 2) & 0x03FFFFFFu);
}

FE_HIDDEN bool tailMatches(uintptr_t callAddress) {
    for (size_t i = 0; i < 3u; ++i) {
        if (readWord(callAddress + 4u + i * 4u) != ItemGlintTail[i])
            return false;
    }
    return true;
}

FE_HIDDEN bool applyCallPatch(CallPatch &patch) {
    const uint32_t current = readWord(patch.address);
    if (current == patch.replacement) {
        __atomic_store_n(&patch.state, 2, __ATOMIC_RELEASE);
        return true;
    }
    if (current != patch.original) {
        __android_log_print(platform::LogError, platform::LogTag,
                            "Item::isGlint call mismatch at %p: %08X",
                            reinterpret_cast<void *>(patch.address),
                            static_cast<unsigned>(current));
        return false;
    }
    if (!writeCode(patch.address, &patch.replacement, 1u)) return false;
    __atomic_store_n(&patch.state, 1, __ATOMIC_RELEASE);
    return true;
}
} // namespace

FE_HIDDEN bool installGlintCompatibilityHooks(const uintptr_t callSites[2],
                                              uintptr_t typedCheckAddress,
                                              uintptr_t rawCheckAddress) {
    if (__atomic_load_n(&InstalledCount, __ATOMIC_ACQUIRE) != 0u)
        return true;
    if (!callSites || !typedCheckAddress || !rawCheckAddress) return false;

    unsigned applied = 0u;
    for (size_t i = 0; i < ExpectedSites; ++i) {
        const uintptr_t call = callSites[i];
        if (!call || !tailMatches(call)) {
            __android_log_print(platform::LogError, platform::LogTag,
                                "Item::isGlint tail mismatch at %p",
                                reinterpret_cast<void *>(call));
            continue;
        }
        const uint32_t current = readWord(call);
        const uintptr_t currentTarget = decodeBranch(call, current);
        if (currentTarget != typedCheckAddress && currentTarget != rawCheckAddress) {
            __android_log_print(platform::LogError, platform::LogTag,
                                "Item::isGlint target mismatch at %p -> %p",
                                reinterpret_cast<void *>(call),
                                reinterpret_cast<void *>(currentTarget));
            continue;
        }

        const uint32_t typedCall = encodeBl(call, typedCheckAddress);
        const uint32_t rawCall = encodeBl(call, rawCheckAddress);
        if (!typedCall || !rawCall) continue;
        Patches[i] = {call, typedCall, rawCall, 0};
        if (applyCallPatch(Patches[i])) ++applied;
    }

    __atomic_store_n(&InstalledCount, applied, __ATOMIC_RELEASE);
    if (applied != ExpectedSites) {
        __android_log_print(platform::LogWarn, platform::LogTag,
                            "Item::isGlint raw-ench redirects: %u/2",
                            applied);
        return applied != 0u;
    }
    __android_log_print(platform::LogInfo, platform::LogTag,
                        "Item::isGlint raw-ench redirects installed: 2/2");
    return true;
}

FE_HIDDEN void uninstallGlintCompatibilityHook() {
    for (size_t i = ExpectedSites; i > 0; --i) {
        CallPatch &patch = Patches[i - 1u];
        if (__atomic_load_n(&patch.state, __ATOMIC_ACQUIRE) == 1 &&
            patch.address && readWord(patch.address) == patch.replacement) {
            if (!writeCode(patch.address, &patch.original, 1u)) {
                __android_log_print(platform::LogWarn, platform::LogTag,
                                    "Could not restore Item::isGlint call %zu",
                                    i - 1u);
            }
        }
        patch = {};
    }
    __atomic_store_n(&InstalledCount, 0u, __ATOMIC_RELEASE);
}

FE_HIDDEN bool glintCompatibilityHookActive() {
    return __atomic_load_n(&InstalledCount, __ATOMIC_ACQUIRE) != 0u;
}

FE_HIDDEN unsigned glintCompatibilityHookCount() {
    return __atomic_load_n(&InstalledCount, __ATOMIC_ACQUIRE);
}
} // namespace force_enchant
