#pragma once

#include "Types.h"

namespace force_enchant {

// Registers the ForceEnchantLL module using the exact Android libc++
// optimized std::function ABI used by Levi Launchroid's preloader.
FE_HIDDEN bool registerForceEnchantModMenu();
FE_HIDDEN bool forceEnchantModMenuRegistered();
FE_HIDDEN void unregisterForceEnchantModMenu();

} // namespace force_enchant
