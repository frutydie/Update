#include "RomanNumerals.h"
#include "MemoryMap.h"
#include "Platform.h"

namespace force_enchant {
namespace {
inline constexpr size_t HookWords = 4u;
inline constexpr uint32_t LdrX16Literal8 = 0x58000050u;
inline constexpr uint32_t BranchX16 = 0xD61F0200u;

// Beginning of the decimal formatting block in MCBE 1.26.45.0.
inline constexpr uint32_t NumericBlockEntry[4] = {
    0xD10103A0u, // SUB X0,X29,#0x40 (temporary char buffer)
    0x91005008u, // ADD X8,X0,#0x14
    0x37F800B4u, // TBNZ W20,#31,negative
    0xCB000108u, // SUB X8,X8,X0
};

struct HookState {
    uintptr_t target{};
    uint32_t saved[HookWords]{};
    volatile int installed{};
};
HookState Hook{};

FE_HIDDEN void makeAbsoluteBranch(uint32_t output[HookWords],
                                  uintptr_t destination) {
    output[0] = LdrX16Literal8;
    output[1] = BranchX16;
    output[2] = static_cast<uint32_t>(destination & 0xFFFFFFFFu);
    output[3] = static_cast<uint32_t>((destination >> 32u) & 0xFFFFFFFFu);
}

FE_HIDDEN char *appendChar(char *output, char value) {
    *output = value;
    return output + 1;
}

FE_HIDDEN char *appendRepeated(char *output, char value, unsigned count) {
    for (unsigned i = 0; i < count; ++i) output = appendChar(output, value);
    return output;
}

struct RomanToken {
    unsigned value;
    const char *text;
    unsigned length;
};

inline constexpr RomanToken Tokens[] = {
    {900u, "CM", 2u}, {500u, "D", 1u},  {400u, "CD", 2u},
    {100u, "C", 1u},  {90u, "XC", 2u},  {50u, "L", 1u},
    {40u, "XL", 2u},  {10u, "X", 1u},   {9u, "IX", 2u},
    {5u, "V", 1u},    {4u, "IV", 2u},   {1u, "I", 1u},
};
} // namespace

extern "C" FE_HIDDEN volatile int feRomanEnabled = 0;
extern "C" FE_HIDDEN uintptr_t feRomanBlockContinuation = 0;

extern "C" FE_HIDDEN char *fe_write_decimal_chars(char *output,
                                                    unsigned value) {
    char reversed[10]{};
    unsigned count = 0;
    do {
        reversed[count++] = static_cast<char>('0' + (value % 10u));
        value /= 10u;
    } while (value != 0u && count < sizeof(reversed));
    while (count != 0u) *output++ = reversed[--count];
    return output;
}

extern "C" FE_HIDDEN char *fe_write_roman_chars(char *output,
                                                  unsigned value) {
    if (value == 0u) return appendChar(output, '0');

    // Extended compact convention requested by the user:
    // 32767 -> XXXMMDCCLXVII.
    output = appendRepeated(output, 'X', value / 10000u);
    value %= 10000u;
    output = appendRepeated(output, 'M', value / 1000u);
    value %= 1000u;
    for (const RomanToken &token : Tokens) {
        while (value >= token.value) {
            for (unsigned i = 0; i < token.length; ++i)
                output = appendChar(output, token.text[i]);
            value -= token.value;
        }
    }
    return output;
}

extern "C" FE_HIDDEN void fe_roman_block_dispatch();

FE_HIDDEN void setRomanNumeralsEnabled(bool enabled) {
    __atomic_store_n(&feRomanEnabled, enabled ? 1 : 0, __ATOMIC_RELEASE);
}

FE_HIDDEN bool romanNumeralsEnabled() {
    return __atomic_load_n(&feRomanEnabled, __ATOMIC_ACQUIRE) != 0;
}

FE_HIDDEN bool installRomanNumeralHook(uintptr_t numericBlockAddress,
                                       uintptr_t continuationAddress) {
    if (__atomic_load_n(&Hook.installed, __ATOMIC_ACQUIRE) != 0)
        return Hook.target == numericBlockAddress &&
               feRomanBlockContinuation == continuationAddress;
    if (!numericBlockAddress || !continuationAddress ||
        !wordsEqual(numericBlockAddress, NumericBlockEntry, 4u)) {
        __android_log_print(platform::LogError, platform::LogTag,
                            "Roman numeric block mismatch at %p",
                            reinterpret_cast<void *>(numericBlockAddress));
        return false;
    }

    Hook.target = numericBlockAddress;
    for (size_t i = 0; i < HookWords; ++i)
        Hook.saved[i] = readWord(numericBlockAddress + i * 4u);
    feRomanBlockContinuation = continuationAddress;

    uint32_t redirect[HookWords]{};
    makeAbsoluteBranch(redirect,
                       reinterpret_cast<uintptr_t>(&fe_roman_block_dispatch));
    if (!writeCode(numericBlockAddress, redirect, HookWords)) {
        Hook = {};
        feRomanBlockContinuation = 0;
        __android_log_print(platform::LogError, platform::LogTag,
                            "Could not install Roman numeric block hook");
        return false;
    }
    __atomic_store_n(&Hook.installed, 1, __ATOMIC_RELEASE);
    return true;
}

FE_HIDDEN void uninstallRomanNumeralHook() {
    if (__atomic_load_n(&Hook.installed, __ATOMIC_ACQUIRE) == 0) return;
    if (Hook.target && !writeCode(Hook.target, Hook.saved, HookWords)) {
        __android_log_print(platform::LogWarn, platform::LogTag,
                            "Could not restore Roman numeric block");
    }
    Hook = {};
    feRomanBlockContinuation = 0;
}

FE_HIDDEN bool romanNumeralHookActive() {
    return __atomic_load_n(&Hook.installed, __ATOMIC_ACQUIRE) != 0;
}
} // namespace force_enchant
