#pragma once

using size_t = __SIZE_TYPE__;
using ssize_t = __INTPTR_TYPE__;
using uintptr_t = __UINTPTR_TYPE__;
using uint32_t = unsigned int;
using pthread_t = unsigned long;

#define FE_EXPORT __attribute__((visibility("default")))
#define FE_HIDDEN __attribute__((visibility("hidden")))
