#pragma once

#include "Types.h"

namespace force_enchant {

struct MemoryRegion {
    uintptr_t start{};
    uintptr_t end{};
    int protection{};
};

struct ModuleLayout {
    static constexpr size_t MaxExecRegions = 8;
    static constexpr size_t MaxDataRegions = 32;
    MemoryRegion exec[MaxExecRegions]{};
    MemoryRegion data[MaxDataRegions]{};
    size_t execCount{};
    size_t dataCount{};
};

FE_HIDDEN bool getMinecraftLayout(ModuleLayout &layout);
FE_HIDDEN uintptr_t getMinecraftBase();
FE_HIDDEN uint32_t readWord(uintptr_t address);
FE_HIDDEN uintptr_t readPointer(uintptr_t address);
FE_HIDDEN bool wordsEqual(uintptr_t address, const uint32_t *words,
                          size_t wordCount);
FE_HIDDEN bool ensureCodeReadable(uintptr_t address, size_t length);
FE_HIDDEN bool writeCode(uintptr_t address, const uint32_t *words,
                         size_t wordCount);
FE_HIDDEN bool writePointer(uintptr_t address, uintptr_t value,
                            int originalProtection);

} // namespace force_enchant
