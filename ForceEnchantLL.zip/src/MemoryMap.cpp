#include "MemoryMap.h"
#include "Platform.h"

namespace force_enchant {
namespace {
inline constexpr char MapsPath[] = "/proc/self/maps";
inline constexpr char ModuleNeedle[] = "libminecraftpe.so";

FE_HIDDEN bool containsText(const char *text, size_t textLength,
                            const char *needle, size_t needleLength) {
    if (!text || !needle || needleLength == 0 || textLength < needleLength)
        return false;
    for (size_t i = 0; i + needleLength <= textLength; ++i) {
        size_t j = 0;
        while (j < needleLength && text[i + j] == needle[j]) ++j;
        if (j == needleLength) return true;
    }
    return false;
}

FE_HIDDEN int hexDigit(char value) {
    if (value >= '0' && value <= '9') return value - '0';
    if (value >= 'a' && value <= 'f') return value - 'a' + 10;
    if (value >= 'A' && value <= 'F') return value - 'A' + 10;
    return -1;
}

FE_HIDDEN bool parseHex(const char *line, size_t length, size_t &cursor,
                        uintptr_t &result) {
    result = 0;
    bool found = false;
    while (cursor < length) {
        const int digit = hexDigit(line[cursor]);
        if (digit < 0) break;
        found = true;
        result = (result << 4u) | static_cast<uintptr_t>(digit);
        ++cursor;
    }
    return found;
}

FE_HIDDEN void skipSpaces(const char *line, size_t length, size_t &cursor) {
    while (cursor < length && line[cursor] == ' ') ++cursor;
}

FE_HIDDEN bool parseModuleLine(const char *line, size_t length,
                               MemoryRegion &region, bool &executable) {
    constexpr size_t moduleLength = sizeof(ModuleNeedle) - 1;
    if (!containsText(line, length, ModuleNeedle, moduleLength)) return false;

    size_t cursor = 0;
    uintptr_t start = 0;
    uintptr_t end = 0;
    if (!parseHex(line, length, cursor, start)) return false;
    if (cursor >= length || line[cursor] != '-') return false;
    ++cursor;
    if (!parseHex(line, length, cursor, end) || end <= start) return false;

    skipSpaces(line, length, cursor);
    if (cursor + 4 > length) return false;
    const bool readable = line[cursor] == 'r';
    const bool writable = line[cursor + 1] == 'w';
    executable = line[cursor + 2] == 'x';
    if (!readable) return false;

    int protection = platform::ProtRead;
    if (writable) protection |= platform::ProtWrite;
    if (executable) protection |= platform::ProtExec;
    region = {start, end, protection};
    return true;
}

FE_HIDDEN void writeWordsRaw(uintptr_t address, const uint32_t *words,
                             size_t wordCount) {
    volatile uint32_t *memory = reinterpret_cast<volatile uint32_t *>(address);
    for (size_t i = 0; i < wordCount; ++i) memory[i] = words[i];
}

FE_HIDDEN void clearInstructionCache(uintptr_t address, size_t length) {
    uintptr_t ctr = 0;
    __asm__ volatile("mrs %0, ctr_el0" : "=r"(ctr));
    const uintptr_t dcacheLine = 4u << ((ctr >> 16u) & 0xFu);
    const uintptr_t icacheLine = 4u << (ctr & 0xFu);
    const uintptr_t end = address + length;

    for (uintptr_t p = address & ~(dcacheLine - 1u); p < end; p += dcacheLine)
        __asm__ volatile("dc cvau, %0" :: "r"(p) : "memory");
    __asm__ volatile("dsb ish" ::: "memory");
    for (uintptr_t p = address & ~(icacheLine - 1u); p < end; p += icacheLine)
        __asm__ volatile("ic ivau, %0" :: "r"(p) : "memory");
    __asm__ volatile("dsb ish" ::: "memory");
    __asm__ volatile("isb" ::: "memory");
}

FE_HIDDEN bool changeProtection(uintptr_t address, size_t length,
                                int protection) {
    const uintptr_t pageStart = address & ~(platform::ProtectionGranule - 1u);
    const uintptr_t end = address + length;
    const uintptr_t pageEnd =
        (end + platform::ProtectionGranule - 1u) &
        ~(platform::ProtectionGranule - 1u);
    return mprotect(reinterpret_cast<void *>(pageStart),
                    static_cast<size_t>(pageEnd - pageStart), protection) == 0;
}
} // namespace

FE_HIDDEN uintptr_t getMinecraftBase() {
    const int descriptor = open(MapsPath, platform::OpenReadOnly);
    if (descriptor < 0) return 0;
    char chunk[4096];
    char line[2048];
    size_t lineLength = 0;
    uintptr_t first = 0;
    for (;;) {
        const ssize_t count = read(descriptor, chunk, sizeof(chunk));
        if (count <= 0) break;
        for (ssize_t i = 0; i < count; ++i) {
            const char value = chunk[i];
            if (value == '\n') {
                if (!first && lineLength != 0) {
                    MemoryRegion region{};
                    bool executable = false;
                    if (parseModuleLine(line, lineLength, region, executable)) {
                        first = region.start;
                        break;
                    }
                }
                lineLength = 0;
            } else if (lineLength + 1 < sizeof(line)) {
                line[lineLength++] = value;
            } else {
                lineLength = 0;
            }
        }
        if (first) break;
    }
    close(descriptor);
    return first;
}

FE_HIDDEN bool getMinecraftLayout(ModuleLayout &layout) {
    layout.execCount = 0;
    layout.dataCount = 0;
    const int descriptor = open(MapsPath, platform::OpenReadOnly);
    if (descriptor < 0) return false;

    char chunk[4096];
    char line[2048];
    size_t lineLength = 0;

    for (;;) {
        const ssize_t count = read(descriptor, chunk, sizeof(chunk));
        if (count <= 0) break;
        for (ssize_t i = 0; i < count; ++i) {
            const char value = chunk[i];
            if (value == '\n') {
                MemoryRegion region{};
                bool executable = false;
                if (parseModuleLine(line, lineLength, region, executable)) {
                    if (executable &&
                        layout.execCount < ModuleLayout::MaxExecRegions) {
                        layout.exec[layout.execCount++] = region;
                    } else if (!executable &&
                               layout.dataCount < ModuleLayout::MaxDataRegions) {
                        layout.data[layout.dataCount++] = region;
                    }
                }
                lineLength = 0;
            } else if (lineLength + 1 < sizeof(line)) {
                line[lineLength++] = value;
            } else {
                lineLength = 0;
            }
        }
    }

    close(descriptor);
    return layout.execCount != 0;
}

FE_HIDDEN uint32_t readWord(uintptr_t address) {
    return *reinterpret_cast<const volatile uint32_t *>(address);
}

FE_HIDDEN uintptr_t readPointer(uintptr_t address) {
    return *reinterpret_cast<const volatile uintptr_t *>(address);
}

FE_HIDDEN bool wordsEqual(uintptr_t address, const uint32_t *words,
                          size_t wordCount) {
    if (!address || !words || !wordCount) return false;
    for (size_t i = 0; i < wordCount; ++i) {
        if (readWord(address + i * 4u) != words[i]) return false;
    }
    return true;
}

FE_HIDDEN bool ensureCodeReadable(uintptr_t address, size_t length) {
    if (!address || !length) return false;
    return changeProtection(address, length,
                            platform::ProtRead | platform::ProtExec);
}

FE_HIDDEN bool writeCode(uintptr_t address, const uint32_t *words,
                         size_t wordCount) {
    if (!address || !words || !wordCount) return false;
    const size_t length = wordCount * 4u;
    if (!changeProtection(address, length,
                          platform::ProtRead | platform::ProtWrite |
                              platform::ProtExec)) {
        if (!changeProtection(address, length,
                              platform::ProtRead | platform::ProtWrite)) {
            return false;
        }
    }

    writeWordsRaw(address, words, wordCount);
    clearInstructionCache(address, length);

    if (!changeProtection(address, length,
                          platform::ProtRead | platform::ProtExec)) {
        return false;
    }
    return wordsEqual(address, words, wordCount);
}

FE_HIDDEN bool writePointer(uintptr_t address, uintptr_t value,
                            int originalProtection) {
    if (!address || (address & (sizeof(uintptr_t) - 1u)) != 0u) return false;
    const int writableProtection = originalProtection | platform::ProtWrite;
    if (!changeProtection(address, sizeof(uintptr_t), writableProtection))
        return false;
    *reinterpret_cast<volatile uintptr_t *>(address) = value;
    __asm__ volatile("dmb ish" ::: "memory");
    const bool stored = readPointer(address) == value;
    const bool restored = changeProtection(address, sizeof(uintptr_t),
                                            originalProtection);
    return stored && restored;
}

} // namespace force_enchant
