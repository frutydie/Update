#include "ItemStatBoost.h"
#include "Platform.h"

namespace force_enchant {
namespace {

inline constexpr size_t MaxTargets = 4;
inline constexpr size_t MaxPatchedSlots = 256;

inline constexpr uintptr_t ExactMaxDamageRvas[2] = {
    0x0F46CAE4u, 0x0F6674FCu,
};
inline constexpr uintptr_t ExactArmorRva = 0x0F660650u;
inline constexpr uintptr_t ExactToughnessRva = 0x0F660658u;

// Two verified Item::getMaxDamage implementations used by durable item
// families in the supplied MCBE 1.26.45.0 ARM64 binary.
inline constexpr uint32_t MaxDamageSignature[2] = {
    0x79422000u, // LDRH W0,[X0,#0x110]
    0xD65F03C0u, // RET
};

// The real HumanoidArmorItem armor getter is uniquely identified by the
// adjacent toughness getter in MCBE 1.26.45.0. This avoids an unrelated
// function with the same two-instruction prefix.
inline constexpr uint32_t ArmorValueSignature[5] = {
    0xB941CC00u, // LDR W0,[X0,#0x1CC]
    0xD65F03C0u, // RET
    0xF940EC08u, // next virtual: LDR X8,[X0,#0x1D8]
    0xB9401500u, // LDR W0,[X8,#0x14]
    0xD65F03C0u, // RET
};

// Verified MCBE 1.26.45.0 HumanoidArmorItem toughness getter.
inline constexpr uint32_t ToughnessSignature[3] = {
    0xF940EC08u, // LDR X8,[X0,#0x1D8]
    0xB9401500u, // LDR W0,[X8,#0x14]
    0xD65F03C0u, // RET
};

enum class SlotKind : unsigned char {
    Durability,
    Armor,
    Toughness,
};

struct TargetSet {
    uintptr_t values[MaxTargets]{};
    size_t count{};
};

struct PatchedSlot {
    uintptr_t address{};
    uintptr_t original{};
    uintptr_t replacement{};
    int protection{};
    SlotKind kind{};
};

PatchedSlot Slots[MaxPatchedSlots]{};
size_t SlotCount = 0;
size_t DurabilityCount = 0;
size_t ArmorCount = 0;
size_t ToughnessCount = 0;
volatile int Enabled = 1;
volatile int Installed = 0;

FE_HIDDEN bool matchWords(uintptr_t address, const uint32_t *words,
                          size_t count) {
    for (size_t i = 0; i < count; ++i) {
        if (readWord(address + i * 4u) != words[i]) return false;
    }
    return true;
}

FE_HIDDEN void addTarget(TargetSet &set, uintptr_t value) {
    if (!value) return;
    for (size_t i = 0; i < set.count; ++i) {
        if (set.values[i] == value) return;
    }
    if (set.count < MaxTargets) set.values[set.count++] = value;
}

FE_HIDDEN void locateTargets(const ModuleLayout &layout,
                             TargetSet &maxDamage,
                             TargetSet &armor,
                             TargetSet &toughness) {
    for (size_t regionIndex = 0; regionIndex < layout.execCount; ++regionIndex) {
        const MemoryRegion &region = layout.exec[regionIndex];
        uintptr_t address = (region.start + 3u) & ~uintptr_t(3u);
        const uintptr_t stop = region.end >= 16u ? region.end - 16u : region.start;
        for (; address <= stop; address += 4u) {
            const uint32_t word = readWord(address);
            if (word == MaxDamageSignature[0] &&
                matchWords(address, MaxDamageSignature, 2u)) {
                addTarget(maxDamage, address);
            }
            if (word == ArmorValueSignature[0] &&
                matchWords(address, ArmorValueSignature, 5u)) {
                addTarget(armor, address);
            }
            if (word == ToughnessSignature[0] &&
                matchWords(address, ToughnessSignature, 3u)) {
                addTarget(toughness, address);
            }
        }
    }
}

FE_HIDDEN void recoverExactTargets(uintptr_t base, TargetSet &maxDamage,
                                   TargetSet &armor, TargetSet &toughness) {
    if (!base) return;
    for (uintptr_t rva : ExactMaxDamageRvas) {
        const uintptr_t address = base + rva;
        if (ensureCodeReadable(address, sizeof(MaxDamageSignature)) &&
            matchWords(address, MaxDamageSignature, 2u)) {
            addTarget(maxDamage, address);
        }
    }
    const uintptr_t armorAddress = base + ExactArmorRva;
    if (ensureCodeReadable(armorAddress, sizeof(ArmorValueSignature)) &&
        matchWords(armorAddress, ArmorValueSignature, 5u)) {
        addTarget(armor, armorAddress);
    }
    const uintptr_t toughnessAddress = base + ExactToughnessRva;
    if (ensureCodeReadable(toughnessAddress, sizeof(ToughnessSignature)) &&
        matchWords(toughnessAddress, ToughnessSignature, 3u)) {
        addTarget(toughness, toughnessAddress);
    }
}

FE_HIDDEN bool containsTarget(const TargetSet &set, uintptr_t value) {
    for (size_t i = 0; i < set.count; ++i) {
        if (set.values[i] == value) return true;
    }
    return false;
}

FE_HIDDEN int saturatingDoubleInt(int value) {
    if (value <= 0) return value;
    if (value > 0x3FFFFFFF) return 0x7FFFFFFF;
    return value * 2;
}

extern "C" FE_HIDDEN int feBoostedMaxDamage(void const *item) {
    if (!item) return 0;
    const int base = *reinterpret_cast<unsigned short const *>(
        reinterpret_cast<uintptr_t>(item) + 0x110u);
    return doubleItemStatsEnabled() ? saturatingDoubleInt(base) : base;
}

extern "C" FE_HIDDEN int feBoostedArmorValue(void const *item) {
    if (!item) return 0;
    const int base = *reinterpret_cast<int const *>(
        reinterpret_cast<uintptr_t>(item) + 0x1CCu);
    return doubleItemStatsEnabled() ? saturatingDoubleInt(base) : base;
}

extern "C" FE_HIDDEN int feBoostedToughnessValue(void const *item) {
    if (!item) return 0;
    const uintptr_t component = *reinterpret_cast<uintptr_t const *>(
        reinterpret_cast<uintptr_t>(item) + 0x1D8u);
    if (!component) return 0;
    const int base = *reinterpret_cast<int const *>(component + 0x14u);
    return doubleItemStatsEnabled() ? saturatingDoubleInt(base) : base;
}

FE_HIDDEN uintptr_t replacementFor(SlotKind kind) {
    switch (kind) {
    case SlotKind::Durability:
        return reinterpret_cast<uintptr_t>(&feBoostedMaxDamage);
    case SlotKind::Armor:
        return reinterpret_cast<uintptr_t>(&feBoostedArmorValue);
    case SlotKind::Toughness:
        return reinterpret_cast<uintptr_t>(&feBoostedToughnessValue);
    }
    return 0;
}

FE_HIDDEN bool rememberAndPatch(uintptr_t address, uintptr_t original,
                                int protection, SlotKind kind) {
    if (SlotCount >= MaxPatchedSlots) return false;
    const uintptr_t replacement = replacementFor(kind);
    if (!replacement || !writePointer(address, replacement, protection))
        return false;
    Slots[SlotCount++] = {address, original, replacement, protection, kind};
    switch (kind) {
    case SlotKind::Durability: ++DurabilityCount; break;
    case SlotKind::Armor: ++ArmorCount; break;
    case SlotKind::Toughness: ++ToughnessCount; break;
    }
    return true;
}

} // namespace

FE_HIDDEN void setDoubleItemStatsEnabled(bool enabled) {
    __atomic_store_n(&Enabled, enabled ? 1 : 0, __ATOMIC_RELEASE);
}

FE_HIDDEN bool doubleItemStatsEnabled() {
    return __atomic_load_n(&Enabled, __ATOMIC_ACQUIRE) != 0;
}

FE_HIDDEN bool installItemStatBoost(const ModuleLayout &layout, uintptr_t mcbeBase) {
    if (__atomic_load_n(&Installed, __ATOMIC_ACQUIRE) != 0) return true;

    TargetSet maxDamage{};
    TargetSet armor{};
    TargetSet toughness{};
    locateTargets(layout, maxDamage, armor, toughness);
    if (maxDamage.count != 2u || armor.count != 1u || toughness.count != 1u) {
        recoverExactTargets(mcbeBase, maxDamage, armor, toughness);
    }
    if (maxDamage.count != 2u || armor.count != 1u || toughness.count != 1u) {
        __android_log_print(
            platform::LogWarn, platform::LogTag,
            "Item-stat getter signatures incomplete: durability=%u armor=%u toughness=%u; x2 stats disabled",
            static_cast<unsigned>(maxDamage.count),
            static_cast<unsigned>(armor.count),
            static_cast<unsigned>(toughness.count));
        return false;
    }

    SlotCount = 0;
    DurabilityCount = 0;
    ArmorCount = 0;
    ToughnessCount = 0;

    for (size_t regionIndex = 0; regionIndex < layout.dataCount; ++regionIndex) {
        const MemoryRegion &region = layout.data[regionIndex];
        uintptr_t address = (region.start + sizeof(uintptr_t) - 1u) &
                            ~(uintptr_t(sizeof(uintptr_t) - 1u));
        const uintptr_t stop = region.end >= sizeof(uintptr_t)
                                   ? region.end - sizeof(uintptr_t)
                                   : region.start;
        for (; address <= stop; address += sizeof(uintptr_t)) {
            const uintptr_t value = readPointer(address);
            SlotKind kind{};
            bool matched = false;
            if (containsTarget(maxDamage, value)) {
                kind = SlotKind::Durability;
                matched = true;
            } else if (containsTarget(armor, value)) {
                kind = SlotKind::Armor;
                matched = true;
            } else if (containsTarget(toughness, value)) {
                kind = SlotKind::Toughness;
                matched = true;
            }
            if (!matched) continue;
            if (!rememberAndPatch(address, value, region.protection, kind)) {
                __android_log_print(platform::LogError, platform::LogTag,
                                    "Item-stat vtable patch failed at %p",
                                    reinterpret_cast<void *>(address));
                uninstallItemStatBoost();
                return false;
            }
        }
    }

    if (DurabilityCount == 0u || ArmorCount == 0u || ToughnessCount == 0u) {
        __android_log_print(
            platform::LogWarn, platform::LogTag,
            "Item-stat vtable slots missing: durability=%u armor=%u toughness=%u; x2 stats disabled",
            static_cast<unsigned>(DurabilityCount),
            static_cast<unsigned>(ArmorCount),
            static_cast<unsigned>(ToughnessCount));
        uninstallItemStatBoost();
        return false;
    }

    __atomic_store_n(&Installed, 1, __ATOMIC_RELEASE);
    __android_log_print(
        platform::LogInfo, platform::LogTag,
        "x2 item stats active: durabilitySlots=%u armorSlots=%u toughnessSlots=%u default=ON",
        static_cast<unsigned>(DurabilityCount),
        static_cast<unsigned>(ArmorCount),
        static_cast<unsigned>(ToughnessCount));
    return true;
}

FE_HIDDEN void uninstallItemStatBoost() {
    for (size_t i = SlotCount; i > 0; --i) {
        PatchedSlot &slot = Slots[i - 1u];
        if (readPointer(slot.address) == slot.replacement &&
            !writePointer(slot.address, slot.original, slot.protection)) {
            __android_log_print(platform::LogWarn, platform::LogTag,
                                "Could not restore item-stat vtable slot %p",
                                reinterpret_cast<void *>(slot.address));
        }
        slot = {};
    }
    SlotCount = 0;
    DurabilityCount = 0;
    ArmorCount = 0;
    ToughnessCount = 0;
    __atomic_store_n(&Installed, 0, __ATOMIC_RELEASE);
}

FE_HIDDEN bool itemStatBoostActive() {
    return __atomic_load_n(&Installed, __ATOMIC_ACQUIRE) != 0;
}

FE_HIDDEN size_t boostedDurabilitySlotCount() { return DurabilityCount; }
FE_HIDDEN size_t boostedArmorSlotCount() { return ArmorCount; }
FE_HIDDEN size_t boostedToughnessSlotCount() { return ToughnessCount; }

} // namespace force_enchant
