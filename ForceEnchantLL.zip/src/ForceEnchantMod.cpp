#include "ForceEnchantMod.h"
#include "Patches.h"
#include "ModMenuCompat.h"
#include "Platform.h"

namespace force_enchant {
namespace {
volatile int Enabled = 0;
volatile int WorkerRunning = 0;
volatile int WorkerCreated = 0;
volatile int PermanentFailure = 0;
pthread_t Worker{};

FE_HIDDEN void *patchWorker(void *) {
    bool active = false;
    for (int attempt = 0; attempt < 600; ++attempt) {
        if (__atomic_load_n(&Enabled, __ATOMIC_ACQUIRE) == 0) break;

        const ApplyResult result = locateAndApplyPatches();
        if (result == ApplyResult::Active) {
            active = true;
            break;
        }
        if (result == ApplyResult::PermanentFailure) {
            __atomic_store_n(&PermanentFailure, 1, __ATOMIC_RELEASE);
            break;
        }
        usleep(250000u);
    }

    if (!active && __atomic_load_n(&Enabled, __ATOMIC_ACQUIRE) != 0 &&
        __atomic_load_n(&PermanentFailure, __ATOMIC_ACQUIRE) == 0) {
        __android_log_print(platform::LogError, platform::LogTag,
                            "Timed out waiting for libminecraftpe.so");
    }
    __atomic_store_n(&WorkerRunning, 0, __ATOMIC_RELEASE);
    return nullptr;
}

FE_HIDDEN void joinFinishedWorker() {
    if (__atomic_load_n(&WorkerCreated, __ATOMIC_ACQUIRE) != 0 &&
        __atomic_load_n(&WorkerRunning, __ATOMIC_ACQUIRE) == 0) {
        pthread_join(Worker, nullptr);
        __atomic_store_n(&WorkerCreated, 0, __ATOMIC_RELEASE);
    }
}

FE_HIDDEN void stopAndJoinWorker() {
    __atomic_store_n(&Enabled, 0, __ATOMIC_RELEASE);
    if (__atomic_load_n(&WorkerCreated, __ATOMIC_ACQUIRE) != 0) {
        pthread_join(Worker, nullptr);
        __atomic_store_n(&WorkerCreated, 0, __ATOMIC_RELEASE);
        __atomic_store_n(&WorkerRunning, 0, __ATOMIC_RELEASE);
    }
}
} // namespace

FE_HIDDEN bool load() {
    const bool menuRegistered = registerForceEnchantModMenu();
    __android_log_print(
        platform::LogInfo, platform::LogTag,
        "Loaded ForceEnchantLL v1.6.5 MCBE 1.26.45.x + Levi 1.5.15 build: menu=%s Roman default=OFF DoubleStats default=ON",
        menuRegistered ? "OK" : "FAILED");
    // A Mod Menu rejection is non-fatal. The enchant worker remains usable.
    return true;
}

FE_HIDDEN bool enable() {
    joinFinishedWorker();
    __atomic_store_n(&Enabled, 1, __ATOMIC_RELEASE);

    if (requiredPatchesActive()) {
        __android_log_print(platform::LogInfo, platform::LogTag,
                            "Already active v1.6.5");
        return true;
    }

    if (__atomic_load_n(&PermanentFailure, __ATOMIC_ACQUIRE) != 0) {
        __android_log_print(platform::LogWarn, platform::LogTag,
                            "Previous failure retained; restart after removing old versions");
        return true;
    }

    int expected = 0;
    if (__atomic_compare_exchange_n(&WorkerRunning, &expected, 1, false,
                                    __ATOMIC_ACQ_REL, __ATOMIC_ACQUIRE)) {
        const int result = pthread_create(&Worker, nullptr, patchWorker, nullptr);
        if (result == 0) {
            __atomic_store_n(&WorkerCreated, 1, __ATOMIC_RELEASE);
            __android_log_print(platform::LogInfo, platform::LogTag,
                                "Enable accepted; verified signature scanner started");
        } else {
            __atomic_store_n(&WorkerRunning, 0, __ATOMIC_RELEASE);
            __android_log_print(platform::LogError, platform::LogTag,
                                "pthread_create failed: %d", result);
        }
    }
    return true;
}

FE_HIDDEN bool disable() {
    stopAndJoinWorker();
    revertAllPatches();
    __atomic_store_n(&PermanentFailure, 0, __ATOMIC_RELEASE);
    __android_log_print(platform::LogInfo, platform::LogTag,
                        "Disabled and reverted v1.6.5");
    return true;
}

FE_HIDDEN bool unload() {
    stopAndJoinWorker();
    revertAllPatches();
    unregisterForceEnchantModMenu();
    __atomic_store_n(&PermanentFailure, 0, __ATOMIC_RELEASE);
    __android_log_print(platform::LogInfo, platform::LogTag,
                        "Unloaded v1.6.5");
    return true;
}

} // namespace force_enchant
