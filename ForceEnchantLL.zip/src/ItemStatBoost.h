#pragma once

#include "MemoryMap.h"
#include "Types.h"

namespace force_enchant {

FE_HIDDEN void setDoubleItemStatsEnabled(bool enabled);
FE_HIDDEN bool doubleItemStatsEnabled();
FE_HIDDEN bool installItemStatBoost(const ModuleLayout &layout, uintptr_t mcbeBase);
FE_HIDDEN void uninstallItemStatBoost();
FE_HIDDEN bool itemStatBoostActive();
FE_HIDDEN size_t boostedDurabilitySlotCount();
FE_HIDDEN size_t boostedArmorSlotCount();
FE_HIDDEN size_t boostedToughnessSlotCount();

} // namespace force_enchant
