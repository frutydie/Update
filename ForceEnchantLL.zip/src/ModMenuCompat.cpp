#include "ModMenuCompat.h"
#include "ItemStatBoost.h"
#include "Platform.h"
#include "RomanNumerals.h"

// Minimal placement-new support without depending on C++ runtime headers.
inline void *operator new(size_t, void *memory) noexcept { return memory; }
inline void operator delete(void *, void *) noexcept {}

namespace force_enchant {
namespace {

// Exact public Levi Launchroid 1.5.15 structures recovered from the supplied
// libpreloader.so DWARF. The std::__ndk1::function ABI uses a 32-byte aligned
// inline buffer, a target pointer at +32, and total size 48 bytes.
struct alignas(8) RawString { unsigned char bytes[24]; };
struct alignas(8) RawStringView { const char *data; size_t size; };
struct alignas(8) RawVector { const void *begin; const void *end; const void *capacity; };
struct alignas(16) RawFunction {
    unsigned char buffer[32];
    void *object;
    unsigned char tail[8];
};

struct alignas(8) RawConfigEntry {
    RawString key;
    RawString displayName;
    int type;
    unsigned int padding;
    RawString defaultValue;
    RawString minValue;
    RawString maxValue;
    RawString dependsOn;
};

struct alignas(16) RawModuleInfo {
    RawString moduleId;
    RawString displayName;
    RawString description;
    RawString modId;
    bool defaultEnabled;
    bool hideInHudEditor;
    unsigned char padding[6];
    RawVector configs;
    RawFunction onToggle;
    RawFunction onConfigChanged;
    RawFunction onKeybind;
};

static_assert(sizeof(RawString) == 24);
static_assert(sizeof(RawVector) == 24);
static_assert(sizeof(RawFunction) == 48);
static_assert(__builtin_offsetof(RawFunction, object) == 32);
static_assert(sizeof(RawConfigEntry) == 152);
static_assert(sizeof(RawModuleInfo) == 272);
static_assert(__builtin_offsetof(RawModuleInfo, configs) == 104);
static_assert(__builtin_offsetof(RawModuleInfo, onToggle) == 128);
static_assert(__builtin_offsetof(RawModuleInfo, onConfigChanged) == 176);
static_assert(__builtin_offsetof(RawModuleInfo, onKeybind) == 224);

inline constexpr char ModuleId[] = "force_enchant_ll_163";
inline constexpr char RomanKey[] = "roman_numerals";
inline constexpr char DoubleStatsKey[] = "double_item_stats";
RawConfigEntry Configs[2]{};
RawModuleInfo Module{};
volatile int Registered = 0;

FE_HIDDEN void zeroBytes(void *memory, size_t length) {
    auto *bytes = reinterpret_cast<unsigned char *>(memory);
    for (size_t i = 0; i < length; ++i) bytes[i] = 0;
}

// Android libc++ ABI-v1, little-endian, non-alternate short string layout.
FE_HIDDEN bool makeShortString(RawString &output, const char *text,
                               size_t length) {
    zeroBytes(&output, sizeof(output));
    if (!text || length > 22u) return false;
    output.bytes[0] = static_cast<unsigned char>(length << 1u);
    for (size_t i = 0; i < length; ++i)
        output.bytes[i + 1u] = static_cast<unsigned char>(text[i]);
    return true;
}

FE_HIDDEN bool viewEquals(const RawStringView &view, const char *text,
                          size_t length) {
    if (!view.data || !text || view.size != length) return false;
    for (size_t i = 0; i < length; ++i) {
        if (view.data[i] != text[i]) return false;
    }
    return true;
}

FE_HIDDEN bool parseEnabled(const RawStringView &value) {
    return viewEquals(value, "true", 4u) || viewEquals(value, "1", 1u) ||
           viewEquals(value, "on", 2u) || viewEquals(value, "ON", 2u);
}

// Vtable-compatible implementation of libc++ ABI-v1
// __function::__base<void(string_view,string_view,string_view)>.
// Levi copies this object through __clone(), invokes slot operator(), and
// destroys it through destroy()/destroy_deallocate().
class ConfigChangedCallback final {
public:
    virtual ~ConfigChangedCallback() = default;

    virtual ConfigChangedCallback *clone() const {
        void *memory = mmap(nullptr, platform::ProtectionGranule,
                            platform::ProtRead | platform::ProtWrite,
                            platform::MapPrivate | platform::MapAnonymous,
                            -1, 0);
        if (memory == platform::MapFailed) return nullptr;
        return new (memory) ConfigChangedCallback();
    }

    virtual void cloneInto(ConfigChangedCallback *destination) const {
        if (destination) new (destination) ConfigChangedCallback();
    }

    virtual void destroy() noexcept { this->~ConfigChangedCallback(); }

    virtual void destroyDeallocate() noexcept {
        void *memory = this;
        this->~ConfigChangedCallback();
        munmap(memory, platform::ProtectionGranule);
    }

    virtual void invoke(RawStringView &&moduleId, RawStringView &&key,
                        RawStringView &&value) {
        if (!viewEquals(moduleId, ModuleId, sizeof(ModuleId) - 1u)) return;
        const bool enabled = parseEnabled(value);
        if (viewEquals(key, RomanKey, sizeof(RomanKey) - 1u)) {
            setRomanNumeralsEnabled(enabled);
            __android_log_print(platform::LogInfo, platform::LogTag,
                                "Mod Menu callback: Roman Numerals=%s",
                                enabled ? "ON" : "OFF");
        } else if (viewEquals(key, DoubleStatsKey,
                              sizeof(DoubleStatsKey) - 1u)) {
            setDoubleItemStatsEnabled(enabled);
            __android_log_print(platform::LogInfo, platform::LogTag,
                                "Mod Menu callback: Double Item Stats=%s",
                                enabled ? "ON" : "OFF");
        }
    }

    // RTTI slots are present in Levi's libc++ base interface. ForceEnchantLL
    // does not query callback targets, so null is the safe result.
    virtual const void *target(const void *) const noexcept { return nullptr; }
    virtual const void *targetType() const noexcept { return nullptr; }
};

static_assert(sizeof(ConfigChangedCallback) <= 32u);

FE_HIDDEN void constructConfigCallback(RawFunction &function) {
    zeroBytes(&function, sizeof(function));
    auto *callback = new (function.buffer) ConfigChangedCallback();
    function.object = callback;
}

extern "C" bool registerModuleRaw(const RawModuleInfo &info)
    __asm__("_ZN2pl7modmenu14registerModuleERKNS0_10ModuleInfoE");
extern "C" void unregisterModuleRaw(RawStringView moduleId)
    __asm__("_ZN2pl7modmenu16unregisterModuleENSt6__ndk117basic_string_viewIcNS1_11char_traitsIcEEEE");

} // namespace

FE_HIDDEN bool registerForceEnchantModMenu() {
    if (__atomic_load_n(&Registered, __ATOMIC_ACQUIRE) != 0) return true;

    zeroBytes(&Configs, sizeof(Configs));
    zeroBytes(&Module, sizeof(Module));

    const bool stringsOk =
        makeShortString(Module.moduleId, ModuleId, sizeof(ModuleId) - 1u) &&
        makeShortString(Module.displayName, "ForceEnchantLL", 14u) &&
        makeShortString(Module.description, "Roman + x2 item stats", 21u) &&
        makeShortString(Module.modId, "", 0u) &&
        makeShortString(Configs[0].key, RomanKey, sizeof(RomanKey) - 1u) &&
        makeShortString(Configs[0].displayName, "Roman Numerals", 14u) &&
        makeShortString(Configs[0].defaultValue, "false", 5u) &&
        makeShortString(Configs[0].minValue, "", 0u) &&
        makeShortString(Configs[0].maxValue, "", 0u) &&
        makeShortString(Configs[0].dependsOn, "", 0u) &&
        makeShortString(Configs[1].key, DoubleStatsKey,
                        sizeof(DoubleStatsKey) - 1u) &&
        makeShortString(Configs[1].displayName, "Double Item Stats", 17u) &&
        makeShortString(Configs[1].defaultValue, "true", 4u) &&
        makeShortString(Configs[1].minValue, "", 0u) &&
        makeShortString(Configs[1].maxValue, "", 0u) &&
        makeShortString(Configs[1].dependsOn, "", 0u);
    if (!stringsOk) return false;

    Configs[0].type = 0; // Toggle
    Configs[1].type = 0; // Toggle
    Module.defaultEnabled = true;
    Module.hideInHudEditor = false;
    Module.configs.begin = &Configs[0];
    Module.configs.end = reinterpret_cast<const unsigned char *>(&Configs[0]) +
                         sizeof(Configs);
    Module.configs.capacity = Module.configs.end;

    setRomanNumeralsEnabled(false);
    setDoubleItemStatsEnabled(true);
    constructConfigCallback(Module.onConfigChanged);

    if (!registerModuleRaw(Module)) {
        __android_log_print(platform::LogError, platform::LogTag,
                            "Mod Menu registration rejected");
        return false;
    }

    __atomic_store_n(&Registered, 1, __ATOMIC_RELEASE);
    __android_log_print(
        platform::LogInfo, platform::LogTag,
        "Mod Menu registered with native callback: Roman=OFF DoubleStats=ON");
    return true;
}

FE_HIDDEN bool forceEnchantModMenuRegistered() {
    return __atomic_load_n(&Registered, __ATOMIC_ACQUIRE) != 0;
}

FE_HIDDEN void unregisterForceEnchantModMenu() {
    if (__atomic_load_n(&Registered, __ATOMIC_ACQUIRE) == 0) return;
    unregisterModuleRaw(RawStringView{ModuleId, sizeof(ModuleId) - 1u});
    __atomic_store_n(&Registered, 0, __ATOMIC_RELEASE);
    __android_log_print(platform::LogInfo, platform::LogTag,
                        "Mod Menu unregistered safely");
}

} // namespace force_enchant
