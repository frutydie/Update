#pragma once

#include "Types.h"

namespace force_enchant {
FE_HIDDEN void setRomanNumeralsEnabled(bool enabled);
FE_HIDDEN bool romanNumeralsEnabled();
FE_HIDDEN bool installRomanNumeralHook(uintptr_t numericBlockAddress,
                                       uintptr_t continuationAddress);
FE_HIDDEN void uninstallRomanNumeralHook();
FE_HIDDEN bool romanNumeralHookActive();
}
