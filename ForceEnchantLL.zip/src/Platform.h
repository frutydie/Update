#pragma once

#include "Types.h"

extern "C" {
int __android_log_print(int priority, const char *tag, const char *format, ...);
int open(const char *path, int flags, ...);
ssize_t read(int fd, void *buffer, size_t count);
int close(int fd);
int mprotect(void *address, size_t length, int protection);
void *mmap(void *address, size_t length, int protection, int flags, int fd, long offset);
int munmap(void *address, size_t length);
int usleep(unsigned int microseconds);
int pthread_create(pthread_t *thread, const void *attributes,
                   void *(*entry)(void *), void *argument);
int pthread_join(pthread_t thread, void **result);
void *dlsym(void *handle, const char *symbol);
}

namespace force_enchant::platform {
inline constexpr int LogInfo = 4;
inline constexpr int LogWarn = 5;
inline constexpr int LogError = 6;
inline constexpr int OpenReadOnly = 0;
inline constexpr int ProtRead = 1;
inline constexpr int ProtWrite = 2;
inline constexpr int ProtExec = 4;
inline constexpr int MapPrivate = 2;
inline constexpr int MapAnonymous = 0x20;
inline void *const MapFailed = reinterpret_cast<void *>(~uintptr_t(0));
inline constexpr uintptr_t ProtectionGranule = 0x4000u;
inline constexpr char LogTag[] = "ForceEnchantLL";
}
