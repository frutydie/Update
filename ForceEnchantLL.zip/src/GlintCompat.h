#pragma once

#include "Types.h"

namespace force_enchant {
FE_HIDDEN bool installGlintCompatibilityHooks(const uintptr_t callSites[2],
                                              uintptr_t typedCheckAddress,
                                              uintptr_t rawCheckAddress);
FE_HIDDEN void uninstallGlintCompatibilityHook();
FE_HIDDEN bool glintCompatibilityHookActive();
FE_HIDDEN unsigned glintCompatibilityHookCount();
}
