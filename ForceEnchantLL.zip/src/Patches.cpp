#include "Patches.h"
#include "GlintCompat.h"
#include "ItemStatBoost.h"
#include "Platform.h"
#include "RomanNumerals.h"

namespace force_enchant {
namespace {
inline constexpr size_t ExpectedStorageSites = 2u;

inline constexpr size_t ExpectedInventorySites = 2u;

// Minecraft 1.26.45 inventory rebuild preserve sites. The original
// MOV W2,WZR rejects preservation of non-vanilla enchantments during the
// hotbar/inventory reconstruction path; MOV W2,#1 preserves the stored data.
inline constexpr uintptr_t ExactInventoryRvas[ExpectedInventorySites] = {
    0x0FE3E628u, 0x0FE3E644u,
};
inline constexpr uint32_t InventoryOriginal = 0x2A1F03E2u; // MOV W2,WZR
inline constexpr uint32_t InventoryReplacement = 0x52800022u; // MOV W2,#1

// Exact MCBE 1.26.45.0 AArch64 command signatures.
inline constexpr uint32_t RangeSig[4] = {
    0x2A0003E2u, 0x2A1703E0u, 0x52800021u, 0xAA1303E3u,
};
inline constexpr uint32_t RangePatched = 0x528FFFE2u; // MOV W2,#32767

inline constexpr uint32_t AllowSig[5] = {
    0xB940F282u, // LDR W2,[X20,#0xF0]
    0x910023E8u, // ADD X8,SP,#8
    0xD102E3A0u, // SUB X0,X29,#0xB8
    0x2A1503E1u, // MOV W1,W21
    0x2A1F03E3u, // MOV W3,WZR <- patch
};
inline constexpr uint32_t StorageSig[4] = {
    0xB940F282u, // requested level
    0xD102E3A0u, // held ItemStack
    0x2A1503E1u, // enchantment id
    0x2A1F03E3u, // allowNonVanilla=false <- patch
};
inline constexpr uint32_t NonVanillaPatched = 0x52800023u; // MOV W3,#1

inline constexpr uintptr_t ExactEnchantVectorRva = 0x126E6FE8u;
inline constexpr size_t ExpectedEnchantCount = 42u;
inline constexpr uintptr_t EnchantMaxLevelVtableOffset = 0x30u;

struct EnchantMaxPatch {
    uintptr_t slot{};
    uintptr_t original{};
    bool active{};
};

EnchantMaxPatch EnchantMaxPatches[ExpectedEnchantCount]{};
size_t EnchantMaxPatchCount = 0u;

extern "C" FE_HIDDEN int forceEnchantMaxLevel(void *) {
    return 32767;
}

FE_HIDDEN bool installEnchantMaxLevelOverrides(uintptr_t mcbeBase) {
    const uintptr_t vector = mcbeBase + ExactEnchantVectorRva;
    const uintptr_t begin = readPointer(vector);
    const uintptr_t end = readPointer(vector + sizeof(uintptr_t));
    if (!begin || !end || end < begin || ((end - begin) % sizeof(uintptr_t)) != 0u) {
        __android_log_print(platform::LogError, platform::LogTag,
                            "Enchant vector invalid: begin=%p end=%p",
                            reinterpret_cast<void *>(begin),
                            reinterpret_cast<void *>(end));
        return false;
    }
    const size_t count = static_cast<size_t>((end - begin) / sizeof(uintptr_t));
    if (count != ExpectedEnchantCount) {
        __android_log_print(platform::LogError, platform::LogTag,
                            "Enchant vector count mismatch: got=%u expected=%u",
                            static_cast<unsigned>(count),
                            static_cast<unsigned>(ExpectedEnchantCount));
        return false;
    }

    EnchantMaxPatchCount = 0u;
    for (size_t i = 0; i < count; ++i) {
        const uintptr_t object = readPointer(begin + i * sizeof(uintptr_t));
        if (!object) continue;
        const uintptr_t vtable = readPointer(object);
        if (!vtable) {
            revertAllPatches();
            return false;
        }
        const uintptr_t slot = vtable + EnchantMaxLevelVtableOffset;
        bool duplicate = false;
        for (size_t j = 0; j < EnchantMaxPatchCount; ++j) {
            if (EnchantMaxPatches[j].slot == slot) {
                duplicate = true;
                break;
            }
        }
        if (duplicate) continue;
        const uintptr_t original = readPointer(slot);
        if (!original) {
            revertAllPatches();
            return false;
        }
        EnchantMaxPatches[EnchantMaxPatchCount] = {slot, original, false};
        if (!writePointer(slot, reinterpret_cast<uintptr_t>(&forceEnchantMaxLevel),
                          platform::ProtRead)) {
            __android_log_print(platform::LogError, platform::LogTag,
                                "Failed to override Enchant::getMaxLevel vtable slot %p",
                                reinterpret_cast<void *>(slot));
            EnchantMaxPatchCount = 0u;
            revertAllPatches();
            return false;
        }
        EnchantMaxPatches[EnchantMaxPatchCount].active = true;
        ++EnchantMaxPatchCount;
    }
    if (EnchantMaxPatchCount == 0u) {
        __android_log_print(platform::LogError, platform::LogTag,
                            "No enchant vtables were patched");
        return false;
    }
    __android_log_print(platform::LogInfo, platform::LogTag,
                        "Overrode Enchant::getMaxLevel for %u vtables -> 32767",
                        static_cast<unsigned>(EnchantMaxPatchCount));
    return true;
}

FE_HIDDEN void uninstallEnchantMaxLevelOverrides() {
    for (size_t i = EnchantMaxPatchCount; i > 0; --i) {
        EnchantMaxPatch &patch = EnchantMaxPatches[i - 1u];
        if (patch.active && patch.slot &&
            readPointer(patch.slot) == reinterpret_cast<uintptr_t>(&forceEnchantMaxLevel)) {
            writePointer(patch.slot, patch.original, platform::ProtRead);
        }
        patch = {};
    }
    EnchantMaxPatchCount = 0u;
}

// The two concrete Item::isGlint(ItemStackBase const&) implementations.
// Both call the strict typed `ench`-ListTag predicate, then OR that result with
// the item's static glint bit. v1.6.0 redirects only those BL instructions to
// Minecraft's adjacent raw `ench` existence predicate. This is the actual
// render path; the low-level helper functions themselves remain untouched.
inline constexpr uint32_t ItemGlintTail[3] = {
    0x79422668u, // LDRH W8,[X19,#0x112]
    0x2A080008u, // ORR W8,W0,W8
    0x12000100u, // AND W0,W8,#1
};
inline constexpr uint32_t TypedEnchCheckSig[8] = {
    0xF9400800u, 0xB40000C0u, 0xD0F9DEA1u, 0x911D4421u,
    0x52800082u, 0x52800123u, 0x14383BF6u, 0xD65F03C0u,
};
inline constexpr uint32_t RawEnchCheckSig[7] = {
    0xF9400800u, 0xB40000A0u, 0xD0F9DEA1u, 0x911D4421u,
    0x52800082u, 0x143841A6u, 0xD65F03C0u,
};

// Enchantment tooltip selector and the decimal formatting block.
inline constexpr uint32_t RomanPrefix[3] = {
    0x51000688u, 0x7100251Fu, 0x54000AC8u,
};
inline constexpr uint32_t RomanNumeric[5] = {
    0xD10103A0u, 0x91005008u, 0x37F800B4u, 0xCB000108u,
    0xF100251Fu,
};
inline constexpr uintptr_t RomanContinuationOffset = 0x8Cu;

// Exact RVAs from the user-supplied MCBE 1.26.44.3 binary. These are used only
// as a verified fallback when Android maps late .text pages execute-only and
// the normal readable-region scanner cannot see them.
inline constexpr uintptr_t ExactRangeRva = 0x08FA22DCu;
inline constexpr uintptr_t ExactTypedEnchCheckRva = 0x0F63FC6Cu;
inline constexpr uintptr_t ExactRawEnchCheckRva = 0x0F63FC8Cu;
inline constexpr uintptr_t ExactItemGlintCallRvas[2] = {
    0x0F5107ACu, 0x0F6678ECu,
};
inline constexpr uintptr_t ExactRomanPrefixRva = 0x0F3108F8u;
inline constexpr uintptr_t ExactRomanNumericRva = 0x0F310A58u;

struct PatchSite {
    const char *name;
    uintptr_t address{};
    uint32_t original{};
    uint32_t replacement{};
    volatile int state{}; // 0 inactive, 1 ours, 2 already patched.
};

PatchSite Range{"command level ceiling"};
PatchSite Allow{"any-item validation flag"};
PatchSite Storage[ExpectedStorageSites] = {
    {"real enchant storage A"}, {"real enchant storage B"},
};
PatchSite Inventory[ExpectedInventorySites] = {
    {"inventory rebuild preserve A"}, {"inventory rebuild preserve B"},
};
PatchSite RomanSelector{"numeric/Roman tooltip selector"};

struct LocatedSites {
    uintptr_t range{};
    uintptr_t allow{};
    uintptr_t storage[ExpectedStorageSites]{};
    uintptr_t itemGlintCalls[2]{};
    uintptr_t typedEnchCheck{};
    uintptr_t rawEnchCheck{};
    uintptr_t romanSelector{};
    uintptr_t romanNumeric{};
    size_t rangeCount{};
    size_t allowCount{};
    size_t storageCount{};
    size_t itemGlintCount{};
    size_t typedEnchCheckCount{};
    size_t rawEnchCheckCount{};
    size_t romanPrefixCount{};
    size_t romanNumericCount{};
};

FE_HIDDEN bool matchWords(uintptr_t address, const uint32_t *words,
                          size_t count) {
    for (size_t i = 0; i < count; ++i) {
        if (readWord(address + i * 4u) != words[i]) return false;
    }
    return true;
}

FE_HIDDEN uintptr_t decodeB(uintptr_t instructionAddress,
                            uint32_t instruction) {
    if ((instruction & 0xFC000000u) != 0x14000000u) return 0;
    long long immediate = static_cast<long long>(instruction & 0x03FFFFFFu);
    if (immediate & 0x02000000ll) immediate |= ~0x03FFFFFFll;
    return static_cast<uintptr_t>(
        static_cast<long long>(instructionAddress) + (immediate << 2));
}

FE_HIDDEN uint32_t encodeB(uintptr_t instructionAddress, uintptr_t target) {
    const long long delta = static_cast<long long>(target) -
                            static_cast<long long>(instructionAddress);
    if ((delta & 3ll) != 0 || delta < -(1ll << 27) || delta >= (1ll << 27))
        return 0;
    return 0x14000000u |
           (static_cast<uint32_t>(delta >> 2) & 0x03FFFFFFu);
}

FE_HIDDEN void scanMinecraft(const ModuleLayout &layout, LocatedSites &out) {
    out = {};
    for (size_t r = 0; r < layout.execCount; ++r) {
        const MemoryRegion &region = layout.exec[r];
        uintptr_t address = (region.start + 3u) & ~uintptr_t(3u);
        const uintptr_t stop = region.end > 64u ? region.end - 64u : region.start;
        for (; address <= stop; address += 4u) {
            const uint32_t word = readWord(address);
            if ((word == RangeSig[0] || word == RangePatched) &&
                matchWords(address + 4u, RangeSig + 1u, 3u)) {
                ++out.rangeCount;
                if (out.rangeCount == 1u) out.range = address;
                continue;
            }
            if (word == AllowSig[0] && matchWords(address, AllowSig, 4u) &&
                (readWord(address + 16u) == AllowSig[4] ||
                 readWord(address + 16u) == NonVanillaPatched)) {
                ++out.allowCount;
                if (out.allowCount == 1u) out.allow = address + 16u;
                continue;
            }
            if (word == StorageSig[0] && matchWords(address, StorageSig, 3u) &&
                (readWord(address + 12u) == StorageSig[3] ||
                 readWord(address + 12u) == NonVanillaPatched)) {
                ++out.storageCount;
                if (out.storageCount <= ExpectedStorageSites)
                    out.storage[out.storageCount - 1u] = address + 12u;
                continue;
            }
            if (word == TypedEnchCheckSig[0] &&
                matchWords(address, TypedEnchCheckSig, 8u)) {
                ++out.typedEnchCheckCount;
                if (out.typedEnchCheckCount == 1u)
                    out.typedEnchCheck = address;
                continue;
            }
            if (word == RawEnchCheckSig[0] &&
                matchWords(address, RawEnchCheckSig, 7u)) {
                ++out.rawEnchCheckCount;
                if (out.rawEnchCheckCount == 1u)
                    out.rawEnchCheck = address;
                continue;
            }
            if ((word & 0xFC000000u) == 0x94000000u &&
                matchWords(address + 4u, ItemGlintTail, 3u)) {
                ++out.itemGlintCount;
                if (out.itemGlintCount <= 2u)
                    out.itemGlintCalls[out.itemGlintCount - 1u] = address;
                continue;
            }
            if (word == RomanPrefix[0] &&
                readWord(address + 4u) == RomanPrefix[1]) {
                ++out.romanPrefixCount;
                if (out.romanPrefixCount == 1u)
                    out.romanSelector = address + 8u;
                continue;
            }
            if (word == RomanNumeric[0] &&
                matchWords(address, RomanNumeric, 5u)) {
                ++out.romanNumericCount;
                if (out.romanNumericCount == 1u) out.romanNumeric = address;
            }
        }
    }
}

FE_HIDDEN void recoverOptionalSitesFromExactRvas(LocatedSites &sites) {
    if (sites.rangeCount != 1u || sites.range < ExactRangeRva) return;
    const uintptr_t base = sites.range - ExactRangeRva;
    bool recoveredGlint = false;
    bool recoveredRoman = false;

    if (sites.itemGlintCount != 2u || sites.typedEnchCheckCount != 1u ||
        sites.rawEnchCheckCount != 1u) {
        const uintptr_t typed = base + ExactTypedEnchCheckRva;
        const uintptr_t raw = base + ExactRawEnchCheckRva;
        const bool typedOk = ensureCodeReadable(typed, sizeof(TypedEnchCheckSig)) &&
                             matchWords(typed, TypedEnchCheckSig, 8u);
        const bool rawOk = ensureCodeReadable(raw, sizeof(RawEnchCheckSig)) &&
                           matchWords(raw, RawEnchCheckSig, 7u);
        uintptr_t calls[2]{};
        bool callsOk = typedOk && rawOk;
        for (size_t i = 0; i < 2u; ++i) {
            calls[i] = base + ExactItemGlintCallRvas[i];
            callsOk = callsOk && ensureCodeReadable(calls[i], 16u) &&
                      matchWords(calls[i] + 4u, ItemGlintTail, 3u);
        }
        if (callsOk) {
            sites.typedEnchCheck = typed;
            sites.rawEnchCheck = raw;
            sites.typedEnchCheckCount = 1u;
            sites.rawEnchCheckCount = 1u;
            sites.itemGlintCalls[0] = calls[0];
            sites.itemGlintCalls[1] = calls[1];
            sites.itemGlintCount = 2u;
            recoveredGlint = true;
        }
    }

    if (sites.romanPrefixCount == 0u) {
        const uintptr_t prefix = base + ExactRomanPrefixRva;
        if (ensureCodeReadable(prefix, sizeof(RomanPrefix)) &&
            matchWords(prefix, RomanPrefix, 3u)) {
            sites.romanSelector = prefix + 8u;
            sites.romanPrefixCount = 1u;
            recoveredRoman = true;
        }
    }
    if (sites.romanNumericCount == 0u) {
        const uintptr_t numeric = base + ExactRomanNumericRva;
        if (ensureCodeReadable(numeric, sizeof(RomanNumeric)) &&
            matchWords(numeric, RomanNumeric, 5u)) {
            sites.romanNumeric = numeric;
            sites.romanNumericCount = 1u;
            recoveredRoman = true;
        }
    }

    if (recoveredGlint || recoveredRoman) {
        __android_log_print(
            platform::LogInfo, platform::LogTag,
            "Recovered execute-only visual pages by exact 1.26.45.0 RVA: glint=%s Roman=%s",
            recoveredGlint ? "YES" : "NO",
            recoveredRoman ? "YES" : "NO");
    }
}

FE_HIDDEN bool applySite(PatchSite &site) {
    if (!site.address) return false;
    const uint32_t current = readWord(site.address);
    if (current == site.replacement) {
        __atomic_store_n(&site.state, 2, __ATOMIC_RELEASE);
        return true;
    }
    if (current != site.original) {
        __android_log_print(platform::LogError, platform::LogTag,
                            "%s mismatch at %p: %08X", site.name,
                            reinterpret_cast<void *>(site.address),
                            static_cast<unsigned>(current));
        return false;
    }
    if (!writeCode(site.address, &site.replacement, 1u)) return false;
    __atomic_store_n(&site.state, 1, __ATOMIC_RELEASE);
    return true;
}

FE_HIDDEN void revertSite(PatchSite &site) {
    if (__atomic_load_n(&site.state, __ATOMIC_ACQUIRE) == 1 && site.address &&
        readWord(site.address) == site.replacement) {
        if (!writeCode(site.address, &site.original, 1u)) {
            __android_log_print(platform::LogWarn, platform::LogTag,
                                "Could not restore %s", site.name);
        }
    }
    site.address = 0;
    __atomic_store_n(&site.state, 0, __ATOMIC_RELEASE);
}
} // namespace

FE_HIDDEN ApplyResult locateAndApplyPatches() {
    ModuleLayout layout{};
    if (!getMinecraftLayout(layout)) return ApplyResult::Waiting;

    LocatedSites sites{};
    scanMinecraft(layout, sites);

    // Prefer the verified scanner, but fall back to exact RVAs when Android
    // maps the command page execute-only and it cannot be read by the scanner.
    uintptr_t mcbeBase = 0;
    if (sites.rangeCount == 1u && sites.allowCount == 1u &&
        sites.storageCount == ExpectedStorageSites) {
        mcbeBase = sites.range - ExactRangeRva;
    } else {
        mcbeBase = getMinecraftBase();
        if (!mcbeBase) return ApplyResult::Waiting;
        const uintptr_t range = mcbeBase + ExactRangeRva;
        const uintptr_t allow = mcbeBase + 0x08FA2520u;
        const uintptr_t storage0 = mcbeBase + 0x08FA2620u;
        const uintptr_t storage1 = mcbeBase + 0x08FA2704u;
        if (!ensureCodeReadable(range, 16u) ||
            !ensureCodeReadable(allow, 4u) ||
            !ensureCodeReadable(storage0, 4u) ||
            !ensureCodeReadable(storage1, 4u) ||
            !matchWords(range, RangeSig, 4u) ||
            readWord(allow) != AllowSig[4] ||
            readWord(storage0) != StorageSig[3] ||
            readWord(storage1) != StorageSig[3]) {
            __android_log_print(
                platform::LogError, platform::LogTag,
                "MCBE 1.26.45.x exact core validation failed; stopped");
            return ApplyResult::PermanentFailure;
        }
        sites.range = range;
        sites.allow = allow;
        sites.storage[0] = storage0;
        sites.storage[1] = storage1;
        sites.rangeCount = 1u;
        sites.allowCount = 1u;
        sites.storageCount = ExpectedStorageSites;
        __android_log_print(platform::LogInfo, platform::LogTag,
                            "Using exact 1.26.45.x core RVAs because readable scan was incomplete");
    }

    // Preserve the real enchantment payload when Bedrock reconstructs an
    // ItemStack while switching hotbar slots. These are exact verified sites
    // in the supplied 1.26.45.0 binary.
    for (size_t i = 0; i < ExpectedInventorySites; ++i) {
        const uintptr_t address = mcbeBase + ExactInventoryRvas[i];
        if (!ensureCodeReadable(address, sizeof(uint32_t)) ||
            (readWord(address) != InventoryOriginal &&
             readWord(address) != InventoryReplacement)) {
            __android_log_print(
                platform::LogError, platform::LogTag,
                "1.26.45 inventory preserve site mismatch at %p",
                reinterpret_cast<void *>(address));
            return ApplyResult::PermanentFailure;
        }
        Inventory[i] = {"inventory rebuild preserve", address,
                        InventoryOriginal, InventoryReplacement, 0};
    }

    // Android can map late code pages execute-only. Recover the exact visual
    // sites from the verified supplied binary and validate their bytes before
    // installing either optional hook.
    recoverOptionalSitesFromExactRvas(sites);

    Range = {"command level ceiling", sites.range, RangeSig[0], RangePatched, 0};
    Allow = {"any-item validation flag", sites.allow, AllowSig[4],
             NonVanillaPatched, 0};
    for (size_t i = 0; i < ExpectedStorageSites; ++i) {
        Storage[i].address = sites.storage[i];
        Storage[i].original = StorageSig[3];
        Storage[i].replacement = NonVanillaPatched;
        Storage[i].state = 0;
    }

    if (!applySite(Range) || !applySite(Allow)) {
        revertAllPatches();
        return ApplyResult::PermanentFailure;
    }
    for (size_t i = 0; i < ExpectedStorageSites; ++i) {
        if (!applySite(Storage[i])) {
            revertAllPatches();
            return ApplyResult::PermanentFailure;
        }
    }
    for (size_t i = 0; i < ExpectedInventorySites; ++i) {
        if (!applySite(Inventory[i])) {
            revertAllPatches();
            return ApplyResult::PermanentFailure;
        }
    }

    // The command range patch above is the authoritative max-level override.
    // Do not patch command-parser vtables: the +0x30 virtual call belongs to the
    // generic integer-argument parser, not an enchantment registry object.

    unsigned glintInstalled = 0u;
    bool glintReady = false;
    if (sites.itemGlintCount == 2u && sites.typedEnchCheckCount == 1u &&
        sites.rawEnchCheckCount == 1u) {
        glintReady = installGlintCompatibilityHooks(
            sites.itemGlintCalls, sites.typedEnchCheck, sites.rawEnchCheck);
        glintInstalled = glintCompatibilityHookCount();
    }
    if (!glintReady) {
        __android_log_print(
            platform::LogWarn, platform::LogTag,
            "Optional Item::isGlint redirect unavailable: calls=%u typed=%u raw=%u; enchant core continues",
            static_cast<unsigned>(sites.itemGlintCount),
            static_cast<unsigned>(sites.typedEnchCheckCount),
            static_cast<unsigned>(sites.rawEnchCheckCount));
    }

    bool romanReady = false;
    if (sites.romanPrefixCount == 1u && sites.romanNumericCount == 1u) {
        const uint32_t romanBranch =
            encodeB(sites.romanSelector, sites.romanNumeric);
        if (romanBranch) {
            RomanSelector.address = sites.romanSelector;
            RomanSelector.original = RomanPrefix[2];
            RomanSelector.replacement = romanBranch;
            RomanSelector.state = 0;
            if (installRomanNumeralHook(
                    sites.romanNumeric,
                    sites.romanNumeric + RomanContinuationOffset) &&
                applySite(RomanSelector)) {
                romanReady = true;
            } else {
                revertSite(RomanSelector);
                uninstallRomanNumeralHook();
            }
        }
    }
    if (!romanReady) {
        __android_log_print(
            platform::LogWarn, platform::LogTag,
            "Optional Roman display path unavailable: prefix=%u numeric=%u; numeric display retained",
            static_cast<unsigned>(sites.romanPrefixCount),
            static_cast<unsigned>(sites.romanNumericCount));
    }

    const bool statsReady = installItemStatBoost(layout, mcbeBase);
    if (!statsReady) {
        __android_log_print(platform::LogWarn, platform::LogTag,
                            "x2 armor/tool stats unavailable; enchant core remains active");
    }

    __android_log_print(
        platform::LogInfo, platform::LogTag,
        "ACTIVE v1.6.5: MCBE=1.26.45.x Levi=1.5.15 maxLevel=32767 anyItem=true realStorage=2/2 allEnchantLevelsRaw=true ItemGlintRaw=%u/2 Roman=%s RomanDisplay=%s DoubleItemStats=%s durabilitySlots=%u armorSlots=%u toughnessSlots=%u",
        glintInstalled,
        romanNumeralsEnabled() ? "ON" : "OFF",
        romanReady ? "READY" : "VANILLA-FALLBACK",
        statsReady && doubleItemStatsEnabled() ? "ON" : "OFF",
        static_cast<unsigned>(boostedDurabilitySlotCount()),
        static_cast<unsigned>(boostedArmorSlotCount()),
        static_cast<unsigned>(boostedToughnessSlotCount()));
    return ApplyResult::Active;
}

FE_HIDDEN bool requiredPatchesActive() {
    return __atomic_load_n(&Range.state, __ATOMIC_ACQUIRE) != 0 &&
           __atomic_load_n(&Allow.state, __ATOMIC_ACQUIRE) != 0 &&
           __atomic_load_n(&Storage[0].state, __ATOMIC_ACQUIRE) != 0 &&
           __atomic_load_n(&Storage[1].state, __ATOMIC_ACQUIRE) != 0 &&
           EnchantMaxPatchCount != 0u &&
           __atomic_load_n(&Inventory[0].state, __ATOMIC_ACQUIRE) != 0 &&
           __atomic_load_n(&Inventory[1].state, __ATOMIC_ACQUIRE) != 0;
}

FE_HIDDEN void revertAllPatches() {
    uninstallItemStatBoost();
    revertSite(RomanSelector);
    uninstallRomanNumeralHook();
    uninstallGlintCompatibilityHook();
    for (size_t i = ExpectedInventorySites; i > 0; --i)
        revertSite(Inventory[i - 1u]);
    for (size_t i = ExpectedStorageSites; i > 0; --i)
        revertSite(Storage[i - 1u]);
    revertSite(Allow);
    revertSite(Range);
}
} // namespace force_enchant
