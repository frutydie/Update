#include "ForceEnchantMod.h"

extern "C" FE_EXPORT bool PLMod_Load(void *javaVm, const void *modInfo) {
    (void)javaVm;
    (void)modInfo;
    return force_enchant::load();
}

extern "C" FE_EXPORT bool PLMod_Enable() {
    return force_enchant::enable();
}

extern "C" FE_EXPORT bool PLMod_Disable() {
    return force_enchant::disable();
}

extern "C" FE_EXPORT bool PLMod_Unload() {
    return force_enchant::unload();
}
