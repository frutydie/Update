__attribute__((visibility("default"))) void *dlsym(void *handle, const char *symbol) {
    (void)handle;
    (void)symbol;
    return (void *)0;
}
