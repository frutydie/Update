typedef unsigned long size_t;
typedef long ssize_t;
typedef unsigned long pthread_t;
__attribute__((visibility("default"))) int open(const char *p, int f, ...) { (void)p; (void)f; return -1; }
__attribute__((visibility("default"))) ssize_t read(int fd, void *b, size_t n) { (void)fd; (void)b; (void)n; return -1; }
__attribute__((visibility("default"))) int close(int fd) { (void)fd; return -1; }
__attribute__((visibility("default"))) int mprotect(void *a, size_t n, int p) { (void)a; (void)n; (void)p; return -1; }
__attribute__((visibility("default"))) void *mmap(void *a, size_t n, int p, int f, int d, long o) { (void)a; (void)n; (void)p; (void)f; (void)d; (void)o; return (void*)-1; }
__attribute__((visibility("default"))) int munmap(void *a, size_t n) { (void)a; (void)n; return -1; }
__attribute__((visibility("default"))) int usleep(unsigned int u) { (void)u; return -1; }
__attribute__((visibility("default"))) int pthread_create(pthread_t *t, const void *a, void *(*f)(void *), void *x) { (void)t; (void)a; (void)f; (void)x; return -1; }
__attribute__((visibility("default"))) int pthread_join(pthread_t t, void **v) { (void)t; (void)v; return -1; }
