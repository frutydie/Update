using size_t = __SIZE_TYPE__;
__attribute__((visibility("default")))
void *stringAssignStub(void *self, const char *, size_t)
    __asm__("_ZNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6assignEPKcm");
void *stringAssignStub(void *self, const char *, size_t) { return self; }
