struct ModuleInfoOpaque {};
struct StringViewOpaque { const char *data; unsigned long size; };

bool registerModuleStub(const ModuleInfoOpaque &)
    __asm__("_ZN2pl7modmenu14registerModuleERKNS0_10ModuleInfoE");
bool registerModuleStub(const ModuleInfoOpaque &) { return false; }

void unregisterModuleStub(StringViewOpaque)
    __asm__("_ZN2pl7modmenu16unregisterModuleENSt6__ndk117basic_string_viewIcNS1_11char_traitsIcEEEE");
void unregisterModuleStub(StringViewOpaque) {}

extern "C" void nativeSetExternalModConfigStub(void *, void *, void *, void *, void *)
    __asm__("Java_org_levimc_launcher_core_mods_inbuilt_ExternalModBridge_nativeSetExternalModConfig");
extern "C" void nativeSetExternalModConfigStub(void *, void *, void *, void *, void *) {}
