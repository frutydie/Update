#!/usr/bin/env bash
set -euo pipefail
"$(cd "$(dirname "$0")" && pwd)/build_cache_bypass.sh" "$@"
