#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import struct
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXPECTED_MCBE_SHA = "4492ce15ceda3bb4865788a50e8d35b1bbafd45b62ce441440240a693a97d749"
EXPECTED_PRELOADER_SHA = "e337b78a844677c676712e22ac46d68165b31ca592567903f9a9a092b78c9b3c"


def blob(words: list[int]) -> bytes:
    return b"".join(struct.pack("<I", word) for word in words)


def occurrences(data: bytes, words: list[int]) -> list[int]:
    needle = blob(words)
    result: list[int] = []
    start = 0
    while True:
        pos = data.find(needle, start)
        if pos < 0:
            return result
        if pos % 4 == 0:
            result.append(pos)
        start = pos + 1


def word(data: bytes, offset: int) -> int:
    return struct.unpack_from("<I", data, offset)[0]


def decode_b(address: int, instruction: int) -> int:
    if instruction & 0x7C000000 != 0x14000000:
        return 0
    immediate = instruction & 0x03FFFFFF
    if immediate & 0x02000000:
        immediate -= 0x04000000
    return address + immediate * 4


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_mcbe(path: Path) -> None:
    data = path.read_bytes()
    assert sha(path) == EXPECTED_MCBE_SHA, "unexpected libminecraftpe.so"
    signatures = {
        "range": ([0x2A0003E2, 0x2A1703E0, 0x52800021, 0xAA1303E3], 1),
        "allow": ([0xB940F282, 0x910023E8, 0xD102E3A0,
                   0x2A1503E1, 0x2A1F03E3], 1),
        "storage": ([0xB940F282, 0xD102E3A0, 0x2A1503E1,
                     0x2A1F03E3], 2),
        "typed_ench_check": ([0xF9400800, 0xB40000C0, 0xB0F9DEA1,
                           0x911D4421, 0x52800082, 0x52800123,
                           0x14383BF6, 0xD65F03C0], 1),
        "raw_ench_check": ([0xF9400800, 0xB40000A0, 0xB0F9DEA1,
                           0x911D4421, 0x52800082,
                           0x143841A6, 0xD65F03C0], 1),
        "item_glint_tail": ([0x79422668, 0x2A080008, 0x12000100], 2),
        "roman_prefix": ([0x51000688, 0x7100251F, 0x54000AC8], 1),
        "roman_numeric": ([0xD10103A0, 0x91005008, 0x37F800B4,
                           0xCB000108, 0xF100251F], 1),
        "max_damage": ([0x79422000, 0xD65F03C0], 2),
        "armor_context": ([0xB941CC00, 0xD65F03C0, 0xF940EC08,
                           0xB9401500, 0xD65F03C0], 1),
        "toughness": ([0xF940EC08, 0xB9401500, 0xD65F03C0], 1),
    }
    found: dict[str, list[int]] = {}
    for name, (signature, expected) in signatures.items():
        found[name] = occurrences(data, signature)
        assert len(found[name]) == expected, f"{name}: {found[name]}"

    typed = found["typed_ench_check"][0]
    raw = found["raw_ench_check"][0]
    assert typed == 0x0F6401CC, hex(typed)
    assert raw == 0x0F6401EC, hex(raw)
    item_glint_calls = [offset - 4 for offset in found["item_glint_tail"]]
    assert item_glint_calls == [0x0F510D08, 0x0F667E48], item_glint_calls
    for call in item_glint_calls:
        assert decode_b(call, word(data, call)) == typed, hex(call)

    roman = found["roman_numeric"][0]
    assert roman + 0x8C == 0xF311044
    print(f"MCBE exact binary: PASS ({path})")
    print(f"  range=0x{found['range'][0]:X} allow=0x{found['allow'][0]:X}")
    print(f"  storage={[hex(x) for x in found['storage']]}")
    print(f"  typed_ench=0x{typed:X} raw_ench=0x{raw:X}")
    print(f"  Item::isGlint calls={[hex(x) for x in item_glint_calls]}")
    print(f"  Roman numeric=0x{roman:X} continuation=0x{roman+0x8C:X}")


def verify_preloader(path: Path) -> None:
    data = path.read_bytes()
    assert sha(path) == EXPECTED_PRELOADER_SHA, "unexpected libpreloader.so"
    for symbol in (
        b"_ZN2pl7modmenu14registerModuleERKNS0_10ModuleInfoE",
        b"_ZN2pl7modmenu16unregisterModuleENSt6__ndk117basic_string_viewIcNS1_11char_traitsIcEEEE",
        b"Java_org_levimc_launcher_core_mods_inbuilt_ExternalModBridge_nativeSetExternalModConfig",
    ):
        assert symbol in data, symbol
    source = (ROOT / "src" / "ModMenuCompat.cpp").read_text()
    for text in (
        "sizeof(RawModuleInfo) == 272",
        "sizeof(RawFunction) == 48",
        "onConfigChanged) == 176",
        "onKeybind) == 224",
        "force_enchant_ll_160",
    ):
        assert text in source, text
    print(f"Levi 1.5.15 exact preloader ABI: PASS ({path})")


def verify_source() -> None:
    patches = (ROOT / "src" / "Patches.cpp").read_text()
    roman = (ROOT / "src" / "RomanNumerals.cpp").read_text()
    glint = (ROOT / "src" / "GlintCompat.cpp").read_text()
    stats = (ROOT / "src" / "ItemStatBoost.cpp").read_text()
    assert "MCBE=1.26.44.3 Levi=1.5.15" in patches
    assert "NonVanillaPatched = 0x52800023u" in patches
    assert "RomanContinuationOffset = 0x8Cu" in patches
    assert "ExactRangeRva = 0x08FA237Cu" in patches
    assert "ExactTypedEnchCheckRva = 0x0F6401CCu" in patches
    assert "ExactRawEnchCheckRva = 0x0F6401ECu" in patches
    assert "0x0F510D08u, 0x0F667E48u" in patches
    assert "ExactRomanNumericRva = 0x0F310FB8u" in patches
    assert "recoverOptionalSitesFromExactRvas" in patches
    assert "Optional Item::isGlint redirect unavailable" in patches
    assert "Optional Roman display path unavailable" in patches
    assert "itemGlintCount" in patches
    assert "fe_write_roman_chars" in roman and "fe_write_decimal_chars" in roman
    assert "Item::isGlint raw-ench redirects installed: 2/2" in glint
    assert "encodeBl" in glint and "typedCheckAddress" in glint
    assert "matchWords(address, ArmorValueSignature, 5u)" in stats
    assert "ExactMaxDamageRvas" in stats
    assert "0x0F46D044u, 0x0F667A5Cu" in stats
    assert "ExactArmorRva = 0x0F660BB0u" in stats
    assert "ExactToughnessRva = 0x0F660BB8u" in stats
    assert "recoverExactTargets" in stats
    build = (ROOT / "scripts" / "build_cache_bypass.sh").read_text()
    menu = (ROOT / "src" / "ModMenuCompat.cpp").read_text()
    assert "EnchantCap.cpp" not in build
    assert "ModMenuJniHook.cpp" not in build
    assert "constructConfigCallback" in menu
    assert "virtual void invoke(RawStringView &&moduleId" in menu


def verify_pack(path: Path) -> str:
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
        root = "ForceEnchantLL_v1_6_0"
        manifest_name = f"{root}/manifest.json"
        library_name = f"{root}/libForceEnchantLL_v1_6_0.so"
        assert manifest_name in archive.namelist()
        assert library_name in archive.namelist()
        manifest = json.loads(archive.read(manifest_name))
        assert manifest == {
            "type": "preload-native",
            "name": "libForceEnchantLL.levipack",
            "author": "TheRealBatu",
            "version": "1.6.0",
            "entry": "libForceEnchantLL_v1_6_0.so",
            "icon": "",
            "minecraft_versions": ["1.26.44.3"],
        }
        library = archive.read(library_name)
        assert library[:4] == b"\x7fELF" and library[4] == 2
        assert struct.unpack_from("<H", library, 18)[0] == 183  # AArch64
        for required in (
            b"v1.6.0", b"MCBE=1.26.44.3", b"Levi=1.5.15",
            b"force_enchant_ll_160", b"Roman Numerals",
            b"Double Item Stats", b"libForceEnchantLL_v1_6_0.so",
        ):
            assert required in library, required
        for old in (b"v1.5.4", b"v1.5.3", b"v1.5.2", b"v1.5.1", b"v1.5.0", b"v1.4.0", b"v1.3.5",
                    b"force_enchant_ll_151", b"force_enchant_ll_140"):
            assert old not in library, old

        with tempfile.TemporaryDirectory() as temp:
            so = Path(temp) / "mod.so"
            so.write_bytes(library)
            symbols = subprocess.check_output(["readelf", "-Ws", so], text=True)
            for export in ("PLMod_Load", "PLMod_Enable", "PLMod_Disable", "PLMod_Unload"):
                assert export in symbols, export
            program = subprocess.check_output(["readelf", "-lW", so], text=True)
            for line in program.splitlines():
                if line.strip().startswith("LOAD"):
                    align = int(line.split()[-1], 16)
                    assert align >= 0x4000, line
            dynamic = subprocess.check_output(["readelf", "-dW", so], text=True)
            assert "libForceEnchantLL_v1_6_0.so" in dynamic
    return sha(path)


def main() -> int:
    if len(sys.argv) != 4:
        raise SystemExit("usage: verify_build.py LIBMINECRAFTPE LIBPRELOADER LEVIPACK")
    mcbe, preloader, pack = map(Path, sys.argv[1:])
    verify_source()
    verify_mcbe(mcbe)
    verify_preloader(preloader)
    digest = verify_pack(pack)
    print(f"Levipack: PASS ({pack})")
    print(f"SHA-256: {digest}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
