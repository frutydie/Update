#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/build"
MOD_DIR="ForceEnchantLL_v1_6_5"
LIB="libForceEnchantLL_v1_6_5.so"
MCBE_BINARY="${MCBE_BINARY:-/mnt/data/mcbe_1_26_44_3/libminecraftpe.so}"
PRELOADER_BINARY="${PRELOADER_BINARY:-/mnt/data/mcbe_1_26_44_3/dependencies/libpreloader.so}"
CLANG="${CLANG:-clang}"
CLANGXX="${CLANGXX:-clang++}"
OBJCOPY="${OBJCOPY:-llvm-objcopy}"

rm -rf "$OUT/stubs" "$OUT/package"
mkdir -p "$OUT/stubs" "$OUT/package/$MOD_DIR"

"$CLANG" --target=aarch64-linux-android28 -fuse-ld=lld -Oz -fPIC \
  -fno-stack-protector -fvisibility=hidden -nostdlib -shared \
  -Wl,-soname,liblog.so -Wl,-z,max-page-size=16384 \
  "$ROOT/link_stubs/log_stub.c" -o "$OUT/stubs/liblog.so"
"$CLANG" --target=aarch64-linux-android28 -fuse-ld=lld -Oz -fPIC \
  -fno-stack-protector -fvisibility=hidden -nostdlib -shared \
  -Wl,-soname,libdl.so -Wl,-z,max-page-size=16384 \
  "$ROOT/link_stubs/dl_stub.c" -o "$OUT/stubs/libdl.so"
"$CLANG" --target=aarch64-linux-android28 -fuse-ld=lld -Oz -fPIC \
  -fno-stack-protector -fvisibility=hidden -nostdlib -shared \
  -Wl,-soname,libc.so -Wl,-z,max-page-size=16384 \
  "$ROOT/link_stubs/libc_stub.c" -o "$OUT/stubs/libc.so"
"$CLANGXX" --target=aarch64-linux-android28 -fuse-ld=lld -std=c++20 -Oz -fPIC \
  -fno-exceptions -fno-rtti -fno-stack-protector -fvisibility=hidden \
  -nostdlib -shared -Wl,-soname,libpreloader.so \
  -Wl,-z,max-page-size=16384 "$ROOT/link_stubs/preloader_stub.cpp" \
  -o "$OUT/stubs/libpreloader.so"
"$CLANGXX" --target=aarch64-linux-android28 -fuse-ld=lld -std=c++20 -Oz -fPIC \
  -fno-exceptions -fno-rtti -fno-stack-protector -fvisibility=hidden \
  -nostdlib -shared -Wl,-soname,libc++_shared.so \
  -Wl,-z,max-page-size=16384 "$ROOT/link_stubs/libcpp_stub.cpp" \
  -o "$OUT/stubs/libc++_shared.so"

"$CLANGXX" --target=aarch64-linux-android28 -fuse-ld=lld -std=c++20 -O2 -fPIC \
  -fno-exceptions -fno-rtti -fno-threadsafe-statics -fno-stack-protector \
  -mno-outline-atomics -fvisibility=hidden -nostdlib -shared \
  -Wl,-soname,"$LIB" \
  -Wl,-z,max-page-size=16384 -Wl,-z,common-page-size=16384 \
  -Wl,--build-id=sha1 -Wl,--gc-sections -Wl,-z,now -Wl,-z,relro \
  -Wl,--no-as-needed \
  "$ROOT/src/main.cpp" \
  "$ROOT/src/ForceEnchantMod.cpp" \
  "$ROOT/src/Patches.cpp" \
  "$ROOT/src/GlintCompat.cpp" \
  "$ROOT/src/ItemStatBoost.cpp" \
  "$ROOT/src/RomanNumerals.cpp" \
  "$ROOT/src/RomanDispatch.S" \
  "$ROOT/src/ModMenuCompat.cpp" \
  "$ROOT/src/MemoryMap.cpp" \
  "$OUT/stubs/libpreloader.so" "$OUT/stubs/libc++_shared.so" \
  "$OUT/stubs/liblog.so" "$OUT/stubs/libdl.so" "$OUT/stubs/libc.so" \
  -o "$OUT/$LIB.unstripped"

"$OBJCOPY" --strip-all "$OUT/$LIB.unstripped" "$OUT/$LIB"
cp "$OUT/$LIB" "$OUT/package/$MOD_DIR/$LIB"
cp "$ROOT/manifest.json" "$OUT/package/$MOD_DIR/manifest.json"
printf '%s\n' \
  'ForceEnchantLL exact port for Minecraft Bedrock 1.26.45.x' \
  'Levi Launchroid ABI: 1.5.15' \
  'Version: 1.6.4' \
  "Entry: $LIB" \
  'Features: real any-item enchant storage, level 32767, stored-enchant glint, Roman toggle, x2 item stats' \
  > "$OUT/package/$MOD_DIR/BUILD_INFO.txt"

PACK="$OUT/libForceEnchantLL_V1.6.5_MCBE-1.26.45.x_Levi-1.5.15.levipack"
rm -f "$PACK"
(cd "$OUT/package" && zip -9 -q -r "$PACK" "$MOD_DIR")
python3 "$ROOT/scripts/verify_build.py" "$MCBE_BINARY" "$PRELOADER_BINARY" "$PACK"
echo "$PACK"
